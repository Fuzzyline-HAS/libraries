#include <HAS2_Vibration.h>

#define VIBRATION_MOTOR_PIN1 15
#define VIBRATION_MOTOR_PIN2 13
#define VIBRATION_MOTOR_PIN3 12

VibrationMotor motor1(VIBRATION_MOTOR_PIN1, 1);
VibrationMotor motor2(VIBRATION_MOTOR_PIN2, 2);
VibrationMotor motor3(VIBRATION_MOTOR_PIN3, 3);

void setup(){
    Serial.begin(115200);
    motor1.Setup();
    motor2.Setup();
    motor3.Setup();
}

void loop(){
    motor1.On();
    motor3.Off();
    delay(500);
    motor2.On();
    motor1.Off();
    delay(500);
    motor3.On();
    motor2.Off();
    delay(500);
}